<?php 

$scope = "local";
//$scope = "produccion";

if ($scope=="local") {
	// local
	$servidor = "localhost";
	$cuenta = "root";
	$password = "rootmyapm";
	$database = "psicoexpresate";
}

if ($scope=="produccion") {
	// Produccion
	$servidor = "localhost:3306";
	$cuenta = "sgcco_psico";
	$password = "psicoexpresate12345**";
	$database = "sgcconsu_psicoexpresate";
}

$link = @mysql_connect($servidor, $cuenta, $password) or die ("Error al conectar al servidor.");
@mysql_select_db($database, $link) or die ("Error al conectar a la base de datos.");
$query = "SELECT * FROM eventos";
$result = mysql_query($query,$link);
$row = mysql_fetch_array($result);
$nombre = $row["nombre"];
$fecha = $row["fecha"];
$detalles = $row["detalles"];

?>