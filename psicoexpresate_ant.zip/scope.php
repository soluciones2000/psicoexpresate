<?php 

$scope = "local";
//$scope = "pruebas";
//$scope = "produccion";

?>